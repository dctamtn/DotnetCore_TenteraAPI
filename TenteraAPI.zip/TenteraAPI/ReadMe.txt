# TenteraAPI - Clean Architecture Implementation

## Overview
TenteraAPI is a .NET 9.0 Web API project that follows Clean Architecture principles. This architecture promotes separation of concerns, maintainability, and testability by organizing the codebase into distinct layers.

## Project Structure
The solution is organized into the following layers:

### 1. Domain Layer
- Contains enterprise business rules and entities
- Independent of other layers
- Defines interfaces that other layers must implement
- Houses core business logic and domain models

### 2. Application Layer
- Contains business use cases
- Orchestrates the flow of data to and from entities
- Implements interfaces defined in the Domain layer
- Contains business rules and validation logic

### 3. Infrastructure Layer
- Implements interfaces defined in the Application layer
- Contains external concerns like:
  - Database access (Entity Framework Core)
  - External services integration
  - File system operations
  - Third-party services

### 4. Presentation Layer
- Contains API controllers and endpoints
- Handles HTTP requests and responses
- Implements API versioning and documentation
- Manages authentication and authorization

## Technology Stack
- .NET 9.0
- Entity Framework Core 9.0.5
- SQL Server
- Twilio 7.11.1 (for SMS/communication services)
- OpenAPI/Swagger for API documentation

## Key Features
- Clean Architecture implementation.
- Follow SOLID principles
- Use dependency injection
- Implement proper logging.
- Write unit tests for business logic.
- RESTful API design.
- Entity Framework Core for data access.
- SMS integration with Twilio.
- Google email integration with SmtpClient.
- API documentation with Swagger/OpenAPI.

### Steps to run the Application
Step 1. UnZip project file.
Step 2. Build the solution & Restore NuGet packages
Step 3. Update the connection string in `appsettings.json`
Step 4. Configure TwilioSettings for sending SMS  in `appsettings.json`
Step 5. Configure SmtpSettings for sending email  in `appsettings.json`
Step 6. Run database migrations 'update-database' to apply database code first.
Step 7. Run the application
Step 8. You can test endoints running by swapgger or import file TenteraAPI.postman_collection.json under folder 'TenteraAPI\TenteraAPI' into postman to test endpoint.
Step 9: You can check all unittest working by open tab 'Test Explorer' then run to check all unitest passed & cover all API logic.
Step 10: You can check logging file under folder "TenteraAPI\TenteraAPI\logs\tentera-*.txt" to check when system need check more info that happened when call API. 